import glfw
from OpenGL.GL import *
from OpenGL.GL.shaders import compileProgram, compileShader
import numpy as np
import pyrr

# --- BOILERPLATE INITIALIZATION (Provided) ---
glfw.init()
window = glfw.create_window(1000, 1000, "Assignment 2: 3D Stacker", None, None)
glfw.make_context_current(window)
glEnable(GL_DEPTH_TEST)

# Load Shaders (Ensure basic.vert and basic.frag are in the same folder)
vertex_shader = open("basic.vert").read()
fragment_shader = open("basic.frag").read()
shader = compileProgram(
    compileShader(vertex_shader, GL_VERTEX_SHADER),
    compileShader(fragment_shader, GL_FRAGMENT_SHADER)
)
glUseProgram(shader)

# --- GEOMETRY SETUP (Cubes and Planes) ---
# [Assume VAO/VBO setup for cube_vertices and plane_vertices is here]
# (Refer to original source for vertex data) [cite: 49, 50]

# --- GAME STATE VARIABLES ---
cube_positions = []      # List to store dropped cubes
active_cube_pos = [0, 0.5, 0] 
is_sliding = True
current_layer = 0

# Uniform Locations
offset_loc = glGetUniformLocation(shader, "offset")
color_loc = glGetUniformLocation(shader, "cubeColor")
camera_loc = glGetUniformLocation(shader, "cameraPos")

# --- MAIN RENDER LOOP ---
while not glfw.window_should_close(window):
    glfw.poll_events()
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    
    time = glfw.get_time()

    # -----------------------------------------------------------
    # TASK 1: SLIDING LOGIC
    # TODO: Use math (sin/cos) to make active_cube_pos[0] (X) 
    # move back and forth over time.
    # -----------------------------------------------------------
    
    # -----------------------------------------------------------
    # TASK 2: THE DROP (INPUT)
    # TODO: Detect SPACEBAR press. 
    # When pressed, add active_cube_pos to cube_positions 
    # and increment current_layer.
    # -----------------------------------------------------------

    # -----------------------------------------------------------
    # TASK 3: COLLISION / STACK CHECK
    # TODO: When dropping, check if the active cube's X is 
    # too far from the previous cube's X. 
    # If it is, trigger a "Game Over" or "Fall" state.
    # -----------------------------------------------------------

    # --- RENDERING ---
    # Draw Ground
    glUniform3f(color_loc, 0.5, 0.5, 0.5)
    glUniform3f(offset_loc, 0, -1, 0)
    # glDrawArrays(...)

    # Draw Stacked Cubes
    for pos in cube_positions:
        glUniform3f(offset_loc, pos[0], pos[1], pos[2])
        glUniform3f(color_loc, 0.0, 0.8, 0.0) # Green for stable
        # glDrawArrays(...)

    # Draw Active Cube
    glUniform3f(offset_loc, active_cube_pos[0], active_cube_pos[1], active_cube_pos[2])
    glUniform3f(color_loc, 1.0, 0.5, 0.0) # Orange for active
    # glDrawArrays(...)

    glfw.swap_buffers(window)

glfw.terminate()