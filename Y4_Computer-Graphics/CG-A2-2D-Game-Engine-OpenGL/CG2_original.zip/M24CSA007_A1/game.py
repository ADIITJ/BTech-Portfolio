import numpy as np
import ast

from utils.graphics import Object, Camera, Shader
from assets.shaders.shaders import object_shader
from assets.objects.objects import (
    playerProps, enemyProps, entryProps, exitProps,
    backgroundProps2, sunProps, cloudprops,
    keyProps, doorprops
)


class Game:
    def __init__(self, height, width):
        self.height = height
        self.width = width

        # Game state
        self.state = "GAME"
        self.screen = 0
        self._level_initialized = False

        # Rendering
        self.camera = Camera(height, width)
        self.shaders = [Shader(object_shader["vertex_shader"], object_shader["fragment_shader"])]

        # Gameplay vars
        self.player_health = 100
        self.player_lives = 3
        self.collect_key_check = [False] * 7

        # time tracking
        self.elapsed_time = 0.0
        self._hud_print_accum = 0.0

        # physics flags
        self.is_on_platform = False

        # Physics tuning (you can tune these)
        self.GRAVITY = 150.0           # reduced gravity
        self.JUMP_V = 260.0
        self.MOVE_V = 140.0

        # Collision sizing heuristic
        self.BASE_UNIT = 10.0          # tune if needed (10 is your original implied scale)

    # -----------------------------
    # Level init (only when needed)
    # -----------------------------
    def InitScreen(self, reset_keys=False):
        if reset_keys:
            self.collect_key_check = [False] * 7

        # Background & static props
        self.bg = Object(self.shaders[0], backgroundProps2)
        self.sun = Object(self.shaders[0], sunProps)

        # Entry / Exit
        self.entry = Object(self.shaders[0], entryProps)
        self.entry.properties["position"] = np.array([-460, 320, 0], dtype=np.float32)

        self.exit = Object(self.shaders[0], exitProps)
        self.exit.properties["position"] = np.array([460, -280, 0], dtype=np.float32)

        # Doors
        self.entrydoor = Object(self.shaders[0], doorprops)
        self.entrydoor.properties["position"] = self.entry.properties["position"] + np.array([0, 0, 20], dtype=np.float32)
        self.entrydoor.properties["velocity"] = np.array([0, -30, 0], dtype=np.float32)

        self.exitdoor = Object(self.shaders[0], doorprops)
        self.exitdoor.properties["position"] = self.exit.properties["position"] + np.array([0, 0, 20], dtype=np.float32)
        self.exitdoor.properties["velocity"] = np.array([0, +30, 0], dtype=np.float32)

        # Player
        self.player = Object(self.shaders[0], playerProps)
        self.player.properties["position"] = self.entry.properties["position"] + np.array([0.0, 0.0, 50], dtype=np.float32)
        self.player.properties["velocity"] = np.array([0.0, 0.0, 0.0], dtype=np.float32)

        # Clouds + Keys
        self.cloud = []
        self.keys = []
        for i in range(7):
            cl = Object(self.shaders[0], cloudprops)
            cl.properties["position"] = np.array(
                [
                    (-self.width / 2) + (i + 1) * (self.width / 8),
                    (self.height / 2) - (self.height / 8) * (i + 1),
                    0,
                ],
                dtype=np.float32,
            )
            cl.properties["scale"] = np.array([2, 2, 1], dtype=np.float32)
            cl.properties["velocity"] = np.array([0, 125 + 4 * i, 0], dtype=np.float32)
            self.cloud.append(cl)

            key = Object(self.shaders[0], keyProps)
            key.properties["position"] = cl.properties["position"] + np.array([0, 15, 15], dtype=np.float32)
            key.properties["scale"] = np.array([3, 3, 1], dtype=np.float32)

            if self.collect_key_check[i]:
                key.properties["scale"] = np.array([0, 0, 0], dtype=np.float32)

            self.keys.append(key)

        # Enemies
        self.enemies = []
        for _ in range(5):
            ene = Object(self.shaders[0], enemyProps)
            ene.properties["position"] = np.array(
                [
                    np.random.uniform(-(self.width / 2) + 200, (self.width / 2) - 200),
                    np.random.uniform(-self.height / 2 + 100, self.height / 2 - 100),
                    50,
                ],
                dtype=np.float32,
            )
            ene.properties["velocity"] = np.array([0.0, 0.0, 0.0], dtype=np.float32)
            self.enemies.append(ene)

        self._level_initialized = True

    # -----------------------------
    # Save / Load (no imgui)
    # -----------------------------
    def save_game(self):
        state_data = {
            "screen": int(self.screen),
            "player_lives": int(self.player_lives),
            "player_health": int(self.player_health),
            "collect_key_check": list(self.collect_key_check),
            "elapsed_time": float(self.elapsed_time),
        }
        with open("savegame.txt", "w") as f:
            f.write(repr(state_data))
        print("Saved game -> savegame.txt")

    def load_game(self):
        try:
            with open("savegame.txt", "r") as f:
                data = ast.literal_eval(f.read())

            self.screen = int(data.get("screen", 0))
            self.player_lives = int(data.get("player_lives", 3))
            self.player_health = int(data.get("player_health", 100))
            self.collect_key_check = list(data.get("collect_key_check", [False] * 7))
            self.elapsed_time = float(data.get("elapsed_time", 0.0))

            self.state = "GAME"
            self._level_initialized = False
            print("Loaded game from savegame.txt")

        except Exception as e:
            print("Load game failed:", e)

    # -----------------------------
    # Core loop
    # -----------------------------
    def ProcessFrame(self, inputs, time_dict):
        dt = time_dict["deltaTime"]

        # Window provides: "1","2","W","A","S","D","SPACE"
        if "1" in inputs:
            self.save_game()
        if "2" in inputs:
            self.load_game()

        if not self._level_initialized:
            self.InitScreen(reset_keys=False)

        # Failsafe
        if not hasattr(self, "player") or not hasattr(self, "bg"):
            self._level_initialized = False
            self.InitScreen(reset_keys=False)

        self.elapsed_time += dt

        self.UpdateScene(inputs, time_dict)
        self.DrawScene()
        self._print_hud_to_console(dt)

    def _print_hud_to_console(self, dt):
        self._hud_print_accum += dt
        if self._hud_print_accum >= 1.0:
            self._hud_print_accum = 0.0
            print(
                f"Lives={self.player_lives} | Health={self.player_health} | "
                f"Level={self.screen+1} | Keys={sum(self.collect_key_check)} | "
                f"Time={self.elapsed_time:.1f}s"
            )

    # -----------------------------
    # Helper: clamp X only (do not clamp Y)
    # -----------------------------
    def _clamp_player_x_only(self):
        pos = self.player.properties["position"]
        pos[0] = np.clip(pos[0], -self.width / 2, self.width / 2)
        self.player.properties["position"] = pos

    # -----------------------------
    # Gameplay update
    # -----------------------------
    def UpdateScene(self, inputs, time_dict):
        dt = time_dict["deltaTime"]

        # Horizontal movement
        self.player.properties["velocity"][0] = 0.0
        if "A" in inputs:
            self.player.properties["velocity"][0] = -self.MOVE_V
        if "D" in inputs:
            self.player.properties["velocity"][0] = self.MOVE_V

        # Update clouds and keys
        for i in range(len(self.cloud)):
            cloud = self.cloud[i]
            key = self.keys[i]

            if cloud.properties["position"][1] > (self.height / 2) - 100 or cloud.properties["position"][1] < (-self.height / 2) + 100:
                cloud.properties["velocity"][1] *= -1

            cloud.properties["position"] += cloud.properties["velocity"] * dt
            key.properties["position"] = cloud.properties["position"] + np.array([0, 15, 15], dtype=np.float32)

            # Collect key
            if (not self.collect_key_check[i]) and np.linalg.norm(self.player.properties["position"] - key.properties["position"]) < 40:
                self.collect_key_check[i] = True
                key.properties["scale"] = np.array([0, 0, 0], dtype=np.float32)

        # -----------------------------
        # Platform collision (FIXED)
        # Use bottom-of-player vs top-of-platform
        # -----------------------------
        self.is_on_platform = False
        player_pos = self.player.properties["position"]
        player_vel = self.player.properties["velocity"]

        # approximate half sizes
        player_half_w = 0.5 * self.BASE_UNIT * float(self.player.properties["scale"][0])
        player_half_h = 0.5 * self.BASE_UNIT * float(self.player.properties["scale"][1])

        player_bottom = float(player_pos[1]) - player_half_h

        landed_on = None
        for cloud in self.cloud:
            cloud_pos = cloud.properties["position"]
            cloud_half_w = 0.5 * self.BASE_UNIT * float(cloud.properties["scale"][0])
            cloud_half_h = 0.5 * self.BASE_UNIT * float(cloud.properties["scale"][1])

            platform_top = float(cloud_pos[1]) + cloud_half_h

            # AABB overlap in X
            if abs(float(player_pos[0]) - float(cloud_pos[0])) <= (player_half_w + cloud_half_w):
                # Landing condition
                if player_vel[1] <= 0.0 and (platform_top - 5.0) <= player_bottom <= (platform_top + 15.0):
                    self.is_on_platform = True
                    landed_on = cloud

                    # Snap onto platform
                    player_pos[1] = platform_top + player_half_h
                    player_vel[1] = 0.0
                    break

        # Optional: move with platform (clouds move in Y)
        if self.is_on_platform and landed_on is not None:
            player_pos[1] += float(landed_on.properties["velocity"][1]) * dt

        # Gravity
        if not self.is_on_platform:
            player_vel[1] -= self.GRAVITY * dt

        # Jump
        if self.is_on_platform and "SPACE" in inputs:
            player_vel[1] = self.JUMP_V

        # Integrate player
        self.player.properties["position"] += self.player.properties["velocity"] * dt

        # Clamp X only (do NOT clamp Y)
        self._clamp_player_x_only()

        # Death fall (below screen)
        if self.player.properties["position"][1] < (-self.height / 2) - 200:
            self.player_lives -= 1
            self.player_health = 100
            self.player.properties["position"] = self.entry.properties["position"] + np.array([0.0, 0.0, 50], dtype=np.float32)
            self.player.properties["velocity"][:] = 0.0
            if self.player_lives <= 0:
                print("GAME OVER")
                self.player_lives = 3
                self.player_health = 100
                self.collect_key_check = [False] * 7
                self._level_initialized = False
                return

        # Enemy hit
        for enemy in self.enemies:
            if np.linalg.norm(self.player.properties["position"] - enemy.properties["position"]) < 100:
                self.player_health -= 10
                if self.player_health <= 0:
                    self.player_lives -= 1
                    self.player_health = 100
                    self.player.properties["position"] = self.entry.properties["position"] + np.array([0.0, 0.0, 50], dtype=np.float32)
                    self.player.properties["velocity"][:] = 0.0
                    if self.player_lives <= 0:
                        print("GAME OVER")
                        self.player_lives = 3
                        self.player_health = 100
                        self.collect_key_check = [False] * 7
                        self._level_initialized = False
                        return

        # Doors animate
        self.entrydoor.properties["position"] += self.entrydoor.properties["velocity"] * dt
        self.exitdoor.properties["position"] += self.exitdoor.properties["velocity"] * dt

        # Level transition: require 3 keys
        if np.linalg.norm(self.player.properties["position"] - self.exit.properties["position"]) < 40:
            if sum(self.collect_key_check) >= 3:
                self._next_level()

    def _next_level(self):
        if self.screen < 2:
            self.screen += 1
            self.collect_key_check = [False] * 7
            self._level_initialized = False
            print(f"Moved to Level {self.screen+1}")
        else:
            print("YOU WON!")
            self.screen = 0
            self.collect_key_check = [False] * 7
            self._level_initialized = False

    # -----------------------------
    # Draw
    # -----------------------------
    def DrawScene(self):
        for shader in self.shaders:
            self.camera.Update(shader)

        self.bg.Draw()
        self.sun.Draw()
        self.entry.Draw()
        self.exit.Draw()
        self.entrydoor.Draw()
        self.exitdoor.Draw()
        self.player.Draw()

        for cl in self.cloud:
            cl.Draw()
        for ene in self.enemies:
            ene.Draw()
        for key in self.keys:
            key.Draw()
