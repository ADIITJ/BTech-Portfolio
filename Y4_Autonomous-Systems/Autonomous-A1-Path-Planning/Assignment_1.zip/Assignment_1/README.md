# Multi-Agent Traffic Coordination System

A sophisticated multi-agent system designed to coordinate traffic flow through bottlenecks using the AutoGen framework with LLM-assisted decision making.

## 🏗️ System Architecture

The system implements two main agent types:
- **Bottleneck Agent (B)**: Monitors traffic capacity and broadcasts availability
- **Classroom Agents (C1, C2, C3, ...)**: Manage individual classrooms and negotiate overflow help

## 🚀 Features

- **AutoGen Framework Integration**: Built on Microsoft's AutoGen for robust agent communication
- **LLM Chain Support**: Gemini → OpenRouter → Ollama → Local fallback for intelligent decisions
- **Reciprocal Commitments**: Agents negotiate with "I'll give you X minutes next time" agreements
- **Persistent History**: Commitment tracking across simulation episodes
- **Violation Detection**: Automatic detection when agents exceed 3 commitment failures
- **Real-time Broadcasting**: Deal announcements shared with all agents
- **Capacity-Based Matching**: Intelligent overflow assistance between agents

## 📋 Requirements

- Python 3.12+
- Required packages listed in `requirements.txt`
- API keys for LLM providers (optional - has local fallback)

## ⚙️ Setup

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure Environment** (optional):
   ```bash
   cp .env.example .env
   # Edit .env with your API keys
   ```

3. **Run Demo**:
   ```bash
   python complete_demo.py
   ```

## 🎮 Demo Scenarios

The system demonstrates three scenarios:

1. **Normal**: Standard attendance, balanced flexibility (100% success rate)
2. **Edge**: One classroom with 200 students (stress testing)  
3. **Uncooperative**: One professor with 0.1 flexibility (cooperation limits)

## 📊 Results

- **Overall Success Rate**: 100% (2/2 negotiations successful)
- **LLM Integration**: Authentic reasoning with flexibility overrides
- **Commitment Tracking**: Comprehensive violation detection and history
- **Congestion Management**: Effective but improvable traffic distribution

## 📁 Project Structure

```
Assignment_1/
├── src/                    # Core implementation
│   ├── agents.py          # BottleneckAgent & ClassroomAgent classes
│   ├── llm_chain.py       # LLM fallback chain
│   └── registry.py        # Resource management
├── configs/               # Configuration files
│   └── sim_config.yaml    # Simulation parameters
├── deliverables/          # Academic submission
│   ├── report.tex         # Comprehensive LaTeX report
│   └── *.md              # Documentation
├── complete_demo.py       # Main demonstration script
└── requirements.txt       # Python dependencies
```

## 🏆 Assignment Requirements Fulfilled

✅ AutoGen framework integration  
✅ Multi-agent coordination (B + C1,C2,C3...)  
✅ Bottleneck monitoring & capacity broadcasting  
✅ Reciprocal commitment negotiation system  
✅ Professor flexibility & autonomous decisions  
✅ Commitment history & violation tracking  
✅ LLM fallback chain integration  
✅ Configurable simulation environment

6 comprehensive tests covering:
- Registry atomic operations
- LLM chain fallback behavior
- AutoGen agent instantiation  
- ConversableAgent communication
- End-to-end scenario execution
- Batch computation correctness

## 📈 Performance Characteristics

- **Concurrency**: Thread-safe reservation registry
- **Scalability**: O(n) batch computation, O(1) reservation lookup
- **Reliability**: Two-phase commit prevents double-booking
- **Flexibility**: Configurable professor cooperation levels

## 🎓 Academic Context

Designed for autonomous systems coursework demonstrating:
- Multi-agent coordination patterns
- Negotiation protocols with structured communication
- Resource contention resolution
- AutoGen framework integration
- LLM provider redundancy

## 📝 Assignment Compliance

✅ **AutoGen Integration**: ConversableAgent inheritance with custom message handling  
✅ **Multi-Agent Coordination**: Structured negotiation between classroom agents  
✅ **LLM Chain**: Multiple provider fallback (though JSON used for agent communication)  
✅ **Comprehensive Testing**: 6 tests covering core functionality  
✅ **Documentation**: Detailed README with architecture and usage  

---

*Built with AutoGen 0.2.32, Python 3.10+, and structured agent communication.*