# src/registry.py
# Simple reservation registry with sqlite persistence and CAS versioning.

import sqlite3
import time
import uuid
from typing import Optional, Tuple

DB_PATH = "reservations.db"

def _get_conn():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = _get_conn()
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS reservations (
      id TEXT PRIMARY KEY,
      window_start INTEGER,  -- minute offset relative to nominal T_end
      window_duration INTEGER,
      classroom_id TEXT,
      num_students INTEGER,
      token TEXT,
      status TEXT,
      expires_at INTEGER,
      version INTEGER DEFAULT 0
    )
    """)
    conn.commit()
    conn.close()

class ReservationRegistry:
    def __init__(self):
        init_db()

    def pre_reserve(self, window_start:int, window_duration:int, classroom_id:str, num_students:int, ttl_s=30) -> Tuple[str,int]:
        """Create a tentative reservation. Returns (token, expiry_timestamp)."""
        token = str(uuid.uuid4())
        expires_at = int(time.time()) + ttl_s
        rid = str(uuid.uuid4())
        conn = _get_conn()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO reservations (id, window_start, window_duration, classroom_id, num_students, token, status, expires_at, version) VALUES (?,?,?,?,?,?,?,?,0)",
            (rid, window_start, window_duration, classroom_id, num_students, token, "PENDING", expires_at)
        )
        conn.commit()
        conn.close()
        return token, expires_at

    def commit(self, token:str) -> bool:
        """Commit a previously pre_reserved token. Returns True if committed."""
        conn = _get_conn()
        cur = conn.cursor()
        cur.execute("SELECT id, expires_at, status, version FROM reservations WHERE token=?", (token,))
        row = cur.fetchone()
        if not row:
            conn.close()
            return False
        if row["status"] != "PENDING" or int(time.time()) > row["expires_at"]:
            conn.close()
            return False
        # commit by setting status=COMMITTED and bumping version (CAS style)
        cur.execute("UPDATE reservations SET status='COMMITTED', version=version+1 WHERE id=? AND version=?", (row["id"], row["version"]))
        ok = cur.rowcount == 1
        conn.commit()
        conn.close()
        return ok

    def release(self, token:str) -> bool:
        conn = _get_conn()
        cur = conn.cursor()
        cur.execute("DELETE FROM reservations WHERE token=?", (token,))
        ok = cur.rowcount >= 1
        conn.commit()
        conn.close()
        return ok

    def query_window_load(self, window_start:int, window_duration:int) -> int:
        """Return sum of num_students reserved (PENDING or COMMITTED) overlapping the given window."""
        conn = _get_conn()
        cur = conn.cursor()
        cur.execute("""
        SELECT SUM(num_students) as total FROM reservations
        WHERE NOT (window_start + window_duration <= ? OR window_start >= ?)
        AND status IN ('PENDING','COMMITTED')
        """, (window_start, window_start + window_duration))
        row = cur.fetchone()
        conn.close()
        return int(row["total"] or 0)