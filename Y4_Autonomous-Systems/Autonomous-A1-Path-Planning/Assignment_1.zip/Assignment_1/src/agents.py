# src/agents.py
import math
import random
import time
import json
import os
from typing import List, Dict, Tuple, Optional
from src.registry import ReservationRegistry
from src.llm_chain import call_llm
import autogen
from autogen import ConversableAgent

# Persistence file for commitment history
HISTORY_FILE = "commitment_history.json"

class BottleneckAgent(ConversableAgent):
    def __init__(self, capacity_per_min: int, batch_spacing_min: int = 2):
        # Initialize AutoGen ConversableAgent with disabled LLM (we'll use our own)
        super().__init__(
            name="BottleneckAgent",
            system_message="""You are the Bottleneck Agent (B) responsible for monitoring and coordinating 
            traffic flow through a narrow road bottleneck. Your role is to:
            1. Broadcast capacity information to classroom agents
            2. Manage reservations using two-phase commit (pre-reserve/commit)
            3. Prevent congestion by enforcing batch capacity limits
            4. Track window loads and reject reservations that would cause congestion
            
            Communicate in a professional, coordinator tone.""",
            llm_config=False,  # Disable AutoGen's LLM - we'll use our own
            human_input_mode="NEVER"
        )
        
        self.capacity_per_min = capacity_per_min
        self.batch_spacing_min = batch_spacing_min
        self.registry = ReservationRegistry()
        self.classroom_agents = {}  # Will store references to classroom agents

    @property
    def batch_capacity(self):
        return self.capacity_per_min * self.batch_spacing_min

    def broadcast_capacity(self, estimated_counts: Dict[str, int]) -> Dict:
        """Broadcast capacity information to all classroom agents"""
        broadcast_msg = {
            "type": "BROADCAST_CAPACITY",
            "capacity_per_min": self.capacity_per_min,
            "batch_capacity": self.batch_capacity,
            "estimates": estimated_counts,
            "message": f"Current bottleneck capacity: {self.batch_capacity} students per {self.batch_spacing_min}-minute window"
        }
        
        # Send message to all registered classroom agents using AutoGen
        for agent_id, agent in self.classroom_agents.items():
            try:
                agent.receive(
                    message=json.dumps(broadcast_msg),
                    sender=self,
                    request_reply=False
                )
            except Exception as e:
                print(f"[BottleneckAgent] Failed to send broadcast to {agent_id}: {e}")
        
        return broadcast_msg

    def pre_reserve(self, window_start: int, classroom_id: str, num_students: int, ttl_s=15):
        """Handle pre-reservation requests with capacity checking"""
        current = self.registry.query_window_load(window_start, self.batch_spacing_min)
        if current + num_students > self.batch_capacity:
            return None  # reject pre-reserve immediately
        token, expires_at = self.registry.pre_reserve(
            window_start, self.batch_spacing_min, classroom_id, num_students, ttl_s=ttl_s
        )
        return token

    def commit(self, token: str):
        """Commit a previously pre-reserved token"""
        return self.registry.commit(token)

    def register_classroom_agent(self, agent_id: str, agent):
        """Register classroom agents for communication"""
        self.classroom_agents[agent_id] = agent


class ClassroomAgent(ConversableAgent):
    def __init__(self, cid: str, attendance: int, prof_flexibility: float = 0.7):
        # Initialize AutoGen ConversableAgent with disabled LLM (we'll use our own)
        super().__init__(
            name=f"ClassroomAgent_{cid}",
            system_message=f"""You are Classroom Agent {cid} managing a classroom with {attendance} students.
            Your professor has a flexibility rating of {prof_flexibility:.1f} (0=inflexible, 1=very flexible).
            
            Your responsibilities:
            1. Coordinate with the Bottleneck Agent to avoid congestion
            2. Negotiate with other classroom agents for optimal scheduling
            3. Make and track commitments for future episodes
            4. Compute required batches based on attendance and capacity limits
            5. Respect professor preferences when making scheduling decisions
            
            Communicate professionally and be collaborative while representing your classroom's interests.
            Always consider the professor's flexibility when making commitments.""",
            llm_config=False,  # Disable AutoGen's LLM - we'll use our own
            human_input_mode="NEVER"
        )
        
        self.cid = cid
        self.attendance = attendance
        self.ledger = self._load_commitment_history()  # Load previous commitments
        self.prof_flexibility = prof_flexibility
        self.times_violated = 0
        self.bottleneck_agent = None  # Will be set during initialization
        self.batches = {}  # Track batch assignments: {time_slot: num_students}

    def _load_commitment_history(self) -> List[Dict]:
        """Load commitment history from persistent storage"""
        if os.path.exists(HISTORY_FILE):
            try:
                with open(HISTORY_FILE, 'r') as f:
                    all_history = json.load(f)
                    return all_history.get(self.cid, [])
            except Exception as e:
                print(f"[{self.cid}] Failed to load commitment history: {e}")
        return []
    
    def _save_commitment_history(self):
        """Save commitment history to persistent storage"""
        try:
            all_history = {}
            if os.path.exists(HISTORY_FILE):
                with open(HISTORY_FILE, 'r') as f:
                    all_history = json.load(f)
            
            all_history[self.cid] = self.ledger
            
            with open(HISTORY_FILE, 'w') as f:
                json.dump(all_history, f, indent=2)
        except Exception as e:
            print(f"[{self.cid}] Failed to save commitment history: {e}")

    def compute_batches(self, batch_capacity: int) -> List[int]:
        """Compute required batches based on attendance and capacity"""
        n = math.ceil(self.attendance / batch_capacity)
        batches = []
        for i in range(n-1):
            batches.append(batch_capacity)
        last = self.attendance - batch_capacity * (n-1)
        batches.append(last)
        return batches

    def propose_to(self, other_agent: 'ClassroomAgent', bottleneck: BottleneckAgent, 
                   batch_time: int, num_students: int, reciprocal_minutes=2) -> bool:
        """
        Use AutoGen's messaging framework with LLM assistance to propose scheduling changes.
        This integrates our LLM chain (Ollama -> OpenRouter -> Gemini -> Local) for smarter proposals.
        """
        # Use LLM to determine if professor is willing to initiate proposal
        llm_prompt = f"""
        As classroom agent {self.cid}, should I propose a scheduling change to another agent?
        My professor flexibility: {self.prof_flexibility:.2f}
        Proposal: Move {num_students} students to time slot t{batch_time}
        Offering: {reciprocal_minutes} extra minutes in exchange
        
        Consider the professor's flexibility level and respond with "INITIATE" or "DECLINE" with reasoning.
        """
        
        try:
            llm_response = call_llm(
                prompt=llm_prompt,
                system="You are evaluating whether a professor would initiate a scheduling proposal."
            )
            initiate = "INITIATE" in llm_response.upper()
            
            print(f"[{self.cid}] 🚀 Initiation LLM Response: {llm_response[:100]}...")
            print(f"[{self.cid}] 🤖 LLM Initiation Decision: {'INITIATE' if initiate else 'DECLINE'}")
            
            # Backup with flexibility check
            flexibility_roll = random.random()
            if not initiate and flexibility_roll < self.prof_flexibility:
                initiate = True
                print(f"[{self.cid}] 🎲 Initiation Override: {flexibility_roll:.2f} < {self.prof_flexibility:.2f} → INITIATE")
                
        except Exception as e:
            print(f"[{self.cid}] ❌ LLM Initiation Error: {e}")
            # Fallback to pure flexibility check
            initiate = random.random() < self.prof_flexibility
        
        if not initiate:
            print(f"[{self.cid}] 🚫 Professor refuses to initiate proposal")
            return False  # Professor refuses to initiate proposal
        
        print(f"[{self.cid}] ✅ Professor agrees to initiate proposal")
        
        # Use LLM to craft a persuasive proposal message
        llm_prompt = f"""
        I need to request help from another classroom agent to accommodate {num_students} students.
        My classroom: {self.cid} with {self.attendance} students (OVERFLOW - need help!)
        Target classroom: {other_agent.cid} with {other_agent.attendance} students (has capacity)
        Offering: {reciprocal_minutes} extra minutes in next episode as appreciation
        
        Craft a professional, persuasive request message that:
        1. Explains I have overflow students and need their help
        2. Acknowledges their cooperation and flexibility  
        3. Emphasizes mutual benefit and collaboration
        4. Keeps it concise but compelling
        
        Return just the request message text.
        """
        
        try:
            llm_message = call_llm(
                prompt=llm_prompt,
                system="You are a diplomatic classroom agent requesting help with overflow students."
            )
        except:
            llm_message = f"I have {num_students} overflow students and would appreciate your help in accommodating them. In return, I commit to giving you {reciprocal_minutes} extra minutes in the next episode."
        
        # Create structured proposal message with LLM-generated content
        proposal_msg = {
            "type": "SCHEDULING_PROPOSAL",
            "from": self.cid,
            "to": other_agent.cid,
            "proposal": {
                "batch_time": batch_time,
                "num_students": num_students,
                "reciprocal_minutes": reciprocal_minutes,
                "message": llm_message[:500]  # Limit message length
            }
        }
        
        # Use AutoGen's messaging system
        try:
            print(f"[{self.cid}] 📤 Sending proposal to {other_agent.cid}...")
            
            # Send proposal using AutoGen's initiate_chat method for reliable communication
            chat_result = self.initiate_chat(
                recipient=other_agent,
                message=json.dumps(proposal_msg),
                max_turns=1,
                silent=True
            )
            
            # Extract response from chat result
            response_msg = None
            if chat_result and hasattr(chat_result, 'chat_history') and len(chat_result.chat_history) > 1:
                response_msg = chat_result.chat_history[-1]['content']
            elif chat_result and hasattr(chat_result, 'summary'):
                response_msg = chat_result.summary
            
            print(f"[{self.cid}] 📥 Received response: {response_msg[:200] if response_msg else 'None'}...")
            
            # Parse response
            response_data = None
            if response_msg:
                try:
                    response_data = json.loads(response_msg)
                    print(f"[{self.cid}] 📊 Parsed response data: {response_data}")
                except json.JSONDecodeError as e:
                    print(f"[{self.cid}] ❌ JSON decode error: {e}")
                    pass
            
            # Check if proposal was accepted
            proposal_accepted = (
                response_data and 
                response_data.get("status") == "ACCEPTED"
            )
            
            print(f"[{self.cid}] 📋 Proposal accepted: {proposal_accepted}")
            
            if not proposal_accepted:
                print(f"[{self.cid}] 🚫 Proposal rejected, aborting negotiation")
                return False
            
            # Try to reserve the time slot using two-phase commit
            # The proposing agent (self) is GIVING students, so it reduces its load
            # The receiving agent (other_agent) is RECEIVING students, so it increases its load
            
            # For simplicity in demo, we'll just record the agreement without complex reservations
            # In a full implementation, this would involve proper capacity management
            
            # Record successful negotiation in ledger immediately since LLM accepted
            self.ledger.append({
                "to": other_agent.cid,
                "num_students": num_students,
                "reciprocal_minutes": reciprocal_minutes,
                "status": "ACCEPTED",
                "episode": "current",
                "batch_time": batch_time
            })
            other_agent.ledger.append({
                "from": self.cid,
                "num_students": num_students,
                "reciprocal_minutes": reciprocal_minutes,
                "status": "ACCEPTED", 
                "episode": "next",
                "batch_time": batch_time
            })
            
            # Save updated commitment history for both agents
            self._save_commitment_history()
            other_agent._save_commitment_history()
            return True
                
        except Exception as e:
            print(f"[{self.cid}] Failed to send proposal to {other_agent.cid}: {e}")
            return False

    def receive(self, message, sender, request_reply=True, silent=False):
        """Override receive method to handle custom messages"""
        try:
            # Try to parse structured messages
            msg_data = json.loads(message)
            
            if msg_data.get("type") == "BROADCAST_CAPACITY":
                self._handle_capacity_broadcast(msg_data)
                return None
            elif msg_data.get("type") == "DEAL_ANNOUNCEMENT":
                self._handle_deal_announcement(msg_data)
                return None
            else:
                # Let all other messages (including SCHEDULING_PROPOSAL) go through generate_reply
                return super().receive(message, sender, request_reply, silent)
                
        except (json.JSONDecodeError, KeyError):
            # Fall back to default AutoGen behavior for non-structured messages
            return super().receive(message, sender, request_reply, silent)

    def _handle_capacity_broadcast(self, msg_data: Dict):
        """Handle capacity broadcast from bottleneck agent"""
        print(f"[{self.cid}] Received capacity broadcast: {msg_data['message']}")
        # Store capacity info for decision making
        self.current_batch_capacity = msg_data.get("batch_capacity", 100)
    
    def _handle_deal_announcement(self, msg_data: Dict):
        """Handle deal announcement broadcasts from other agents"""
        deal = msg_data.get("deal", {})
        print(f"[{self.cid}] Deal notification: {deal.get('from')} ↔ {deal.get('to')} moved {deal.get('students')} students")
        # Update internal knowledge of the system state
        # This helps agents make better decisions in future negotiations



    def generate_reply(self, messages=None, sender=None, config=None):
        """
        Override AutoGen's generate_reply to use our custom LLM chain.
        This integrates Ollama -> OpenRouter -> Gemini -> Local fallback.
        """
        if not messages or not isinstance(messages, list) or len(messages) == 0:
            return None
            
        # Get the last message
        last_message = messages[-1]
        
        # Extract content from message dictionary or use the message directly
        if isinstance(last_message, dict):
            content = last_message.get("content", last_message)
        else:
            content = last_message
        
        try:
            # Try to parse as JSON for structured communication
            msg_data = json.loads(content)
            
            if msg_data.get("type") == "SCHEDULING_PROPOSAL":
                # Handle incoming scheduling proposal with LLM assistance
                proposal = msg_data.get("proposal", {})
                
                # Use LLM to make a more intelligent decision
                llm_prompt = f"""
                As a classroom agent, I received a help request for overflow students:
                - From: {msg_data.get("from")}
                - They need help with {proposal.get("num_students")} overflow students at time slot t{proposal.get("batch_time")}
                - In exchange for {proposal.get("reciprocal_minutes")} extra minutes next episode
                - My professor flexibility: {self.prof_flexibility:.2f}
                - My current capacity at that time: {self.batches.get(proposal.get("batch_time"), 0)} students
                
                Should I accept this help request? Consider:
                1. Professor flexibility level
                2. My available capacity at that time slot
                3. Fairness of the exchange
                4. Impact on classroom operations
                
                Respond with "ACCEPT" or "REJECT" followed by brief reasoning.
                """
                
                # Get LLM response using our chain
                llm_response = call_llm(
                    prompt=llm_prompt,
                    system="You are an intelligent classroom coordination agent making scheduling decisions."
                )
                
                # Parse LLM response to determine acceptance
                accept = "ACCEPT" in llm_response.upper()
                
                # Debug logging to see what's happening
                print(f"[{self.cid}] 🔍 LLM Response: {llm_response[:150]}...")
                print(f"[{self.cid}] 🤖 LLM Decision: {'ACCEPT' if accept else 'REJECT'}")
                print(f"[{self.cid}] 📊 Prof Flexibility: {self.prof_flexibility:.2f}")
                
                # Also consider professor flexibility as fallback
                flexibility_roll = random.random()
                if not accept and flexibility_roll < self.prof_flexibility:
                    accept = True
                    print(f"[{self.cid}] 🎲 Flexibility Override: {flexibility_roll:.2f} < {self.prof_flexibility:.2f} → ACCEPT")
                
                print(f"[{self.cid}] ✅ Final Decision: {'ACCEPT' if accept else 'REJECT'}")
                
                response = {
                    "type": "SCHEDULING_RESPONSE",
                    "from": self.cid,
                    "to": msg_data.get("from"),
                    "status": "ACCEPTED" if accept else "REJECTED",
                    "original_proposal": proposal,
                    "reasoning": llm_response[:200]  # Include brief reasoning
                }
                
                # Add to ledger if accepted
                if accept:
                    self.ledger.append({
                        "from": msg_data.get("from"),
                        "num_students": proposal.get("num_students"),
                        "reciprocal_minutes": proposal.get("reciprocal_minutes"),
                        "status": "ACCEPTED",
                        "episode": "next"
                    })
                    # Save updated commitment history
                    self._save_commitment_history()
                
                return json.dumps(response)
            
        except (json.JSONDecodeError, TypeError):
            pass
        
        # For non-structured messages, use LLM for general response
        try:
            llm_response = call_llm(
                prompt=content,
                system=f"You are classroom agent {self.cid}. Respond professionally about scheduling coordination."
            )
            return llm_response
        except:
            # Final fallback
            return "I understand your message, but I'm focused on classroom scheduling coordination."

    def attempt_fulfill_obligations(self):
        """Attempt to fulfill commitments from previous episodes"""
        for commitment in list(self.ledger):
            if commitment.get("status") == "ACCEPTED" and commitment.get("reciprocal_minutes"):
                if random.random() < self.prof_flexibility:
                    commitment["status"] = "FULFILLED"
                    print(f"[{self.cid}] Fulfilled commitment to {commitment.get('to', 'unknown')}")
                else:
                    self.times_violated += 1
                    commitment["status"] = "VIOLATED"
                    print(f"[{self.cid}] Violated commitment to {commitment.get('to', 'unknown')} (violations: {self.times_violated})")
                    
                    # Trigger violation event if >3 violations
                    if self.times_violated > 3:
                        print(f"[{self.cid}] VIOLATION EVENT: {self.times_violated} violations exceeded maximum allowed!")

    def set_bottleneck_agent(self, bottleneck_agent: BottleneckAgent):
        """Set reference to bottleneck agent for communication"""
        self.bottleneck_agent = bottleneck_agent