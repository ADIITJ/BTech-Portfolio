# src/llm_chain.py
# Enhanced LLM provider chain: Gemini -> OpenRouter -> Ollama CLI -> local rule-based fallback.
import os
import shutil
import subprocess
import json
import time
import random
import requests
from typing import Optional

# Load environment variables
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv not available, rely on system env vars

# Import new API clients
try:
    from google import genai
    HAS_GEMINI = True
except ImportError:
    HAS_GEMINI = False

try:
    from openai import OpenAI
    HAS_OPENAI_CLIENT = True
except ImportError:
    HAS_OPENAI_CLIENT = False

def _call_gemini(prompt: str, system: Optional[str]=None) -> Optional[str]:
    """Call Google Gemini API using the new google-genai client."""
    if not HAS_GEMINI:
        return None
    
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        return None
    
    try:
        # Set the API key in environment for the client
        os.environ["GEMINI_API_KEY"] = key
        client = genai.Client()
        
        # Combine system and user prompts
        full_prompt = prompt
        if system:
            full_prompt = f"System: {system}\n\nUser: {prompt}"
        
        response = client.models.generate_content(
            model="gemini-2.5-flash", 
            contents=full_prompt
        )
        
        return response.text.strip() if response.text else None
        
    except Exception as e:
        print(f"[llm_chain] Gemini error: {e}")
        return None

def _call_openrouter_new(prompt: str, system: Optional[str]=None) -> Optional[str]:
    """Call OpenRouter API using the new OpenAI client."""
    if not HAS_OPENAI_CLIENT:
        return None
        
    key = os.getenv("OPENROUTER_API_KEY")
    if not key:
        return None
        
    try:
        client = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=key,
        )
        
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        
        completion = client.chat.completions.create(
            extra_headers={
                "HTTP-Referer": "https://github.com/autonomous-classroom-coordinator",
                "X-Title": "Multi-Agent Traffic Coordinator",
            },
            model="x-ai/grok-4-fast:free",  # Using free model
            messages=messages,
            max_tokens=512,
            temperature=0.7
        )
        
        return completion.choices[0].message.content.strip() if completion.choices[0].message.content else None
        
    except Exception as e:
        print(f"[llm_chain] OpenRouter error: {e}")
        return None

def _call_ollama(prompt: str, model: Optional[str]=None, timeout=10) -> Optional[str]:
    """Try to call local 'ollama' CLI. Return text or None."""
    if shutil.which("ollama") is None:
        return None
    try:
        # get list of models
        proc = subprocess.run(["ollama", "list"], capture_output=True, text=True, timeout=3)
        if proc.returncode != 0:
            return None
        out = proc.stdout.strip()
        models = []
        for line in out.splitlines():
            # basic parsing: skip header lines, take first word tokens as model names
            parts = line.strip().split()
            if parts and parts[0] != "MODEL" and not parts[0].startswith("NAME"):
                models.append(parts[0])
        if not models:
            return None
        model_to_use = model or models[0]
        # run the model, provide prompt through stdin
        run = subprocess.run(["ollama", "run", model_to_use], input=prompt, capture_output=True, text=True, timeout=timeout)
        if run.returncode != 0:
            return None
        text = run.stdout.strip()
        if not text:
            text = run.stderr.strip()
        # Check if the output contains error messages
        if "error:" in text.lower() or "pulling manifest" in text.lower():
            return None
        return text if text else None
    except Exception as e:
        return None

def _call_openrouter_old(prompt: str, system: Optional[str]=None) -> Optional[str]:
    """Legacy OpenRouter implementation using requests (fallback)."""
    key = os.getenv("OPENROUTER_API_KEY")
    if not key:
        return None
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    body = {
        "model": "gpt-4o-mini",  # OpenRouter accepts multiple; user can change
        "messages": [
            {"role": "system", "content": system or "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ],
        "max_tokens": 512,
    }
    try:
        resp = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=body, timeout=15)
        if resp.status_code == 200:
            j = resp.json()
            # adapt to typical chat completion schema
            if "choices" in j and len(j["choices"])>0:
                return j["choices"][0]["message"].get("content","")
            # fallback: return raw text
            return str(j)
        else:
            return None
    except Exception:
        return None



def _local_fallback(prompt: str, system: Optional[str]=None) -> str:
    """Deterministic rule-based fallback LLM used when no external LLM is available."""
    p = prompt.lower()
    
    # Handle proposal initiation decisions
    if "initiate" in p and "decline" in p and "should i propose" in p:
        if "flexibility:" in p:
            try:
                flex_part = p.split("flexibility:")[1].split()[0]
                flexibility = float(flex_part)
                
                if flexibility > 0.6:
                    return "INITIATE - With good professor flexibility, this proposal has merit and could benefit both parties."
                elif flexibility > 0.3:
                    return "INITIATE - Professor flexibility allows for this negotiation attempt."
                else:
                    return "DECLINE - Limited professor flexibility makes scheduling changes difficult."
            except:
                pass
        
        # Default moderate initiation rate
        import random
        if random.random() < 0.8:  # 80% initiation rate
            return "INITIATE - This scheduling proposal could be mutually beneficial."
        else:
            return "DECLINE - Current scheduling constraints prevent this proposal."
    
    # Enhanced negotiation logic for better cooperation
    if "scheduling proposal" in p and "accept" in p and "reject" in p:
        # Extract flexibility and other factors for smarter decisions
        if "flexibility:" in p:
            try:
                flex_part = p.split("flexibility:")[1].split()[0]
                flexibility = float(flex_part)
                
                # More nuanced acceptance based on multiple factors
                if flexibility > 0.6:
                    if "20 students" in p or "students" in p and ("10" in p or "15" in p or "20" in p):
                        return "ACCEPT - This seems like a reasonable proposal that benefits both classrooms. The reciprocal time commitment shows good faith."
                    elif "extra minutes" in p:
                        return "ACCEPT - The offered extra minutes in the next episode make this a fair exchange."
                    else:
                        return "ACCEPT - My professor is flexible enough to accommodate this scheduling change."
                elif flexibility > 0.3:
                    if "extra minutes" in p and ("2" in p or "3" in p):
                        return "ACCEPT - The reciprocal minutes offered make this worthwhile despite some inconvenience."
                    else:
                        return "REJECT - While we appreciate the proposal, our professor's schedule constraints make this difficult."
                else:
                    return "REJECT - Our professor has very limited flexibility for schedule changes at this time."
            except:
                pass
        
        # Fallback to moderate cooperation
        import random
        if random.random() < 0.5:  # 50% acceptance rate for realistic cooperation
            return "ACCEPT - This proposal seems mutually beneficial. We can work together to optimize the schedule."
        else:
            return "REJECT - Unfortunately, our current schedule constraints don't allow for this change."
    
    if "plan_batches" in p or "plan batch" in p:
        # return an example JSON describing batches for demo
        return json.dumps({"batches":[{"class":"C1","time_offset":0,"count":50}]})
    
    if "negotiate" in p:
        return "PROPOSAL: if you move 2 minutes earlier I will compensate in next episode."
    
    if "craft" in p and "proposal" in p:
        # Generate more persuasive proposal messages
        if "20 students" in p:
            return "I have a scheduling challenge with 20 students and would greatly appreciate your cooperation. In exchange for accommodating this small group, I'm committed to providing you extra time in our next coordination session. This mutual support strengthens our collaborative network."
        else:
            return "I'm reaching out regarding a scheduling optimization opportunity. By working together on this timing adjustment, we can both benefit from improved coordination. I'm prepared to offer reciprocal support in future episodes."
    
    if "explain" in p:
        return "This is a deterministic fallback LLM with enhanced cooperation logic. No external API was available."
    
    # generic echo for debugging
    return "FALLBACK_LLM_ECHO: " + prompt[:400]

def call_llm(prompt: str, system: Optional[str]=None) -> str:
    """Unified API. Tries providers in order: Gemini -> OpenRouter -> Ollama -> local fallback."""
    
    # Try Gemini first (highest priority)
    try:
        text = _call_gemini(prompt, system)
        if text:
            print("[llm_chain] using Gemini API")
            return text
    except Exception as e:
        print(f"[llm_chain] Gemini failed: {e}")
        pass
    
    # Try OpenRouter (second priority) 
    try:
        text = _call_openrouter_new(prompt, system)
        if text:
            print("[llm_chain] using OpenRouter API")
            return text
    except Exception as e:
        print(f"[llm_chain] OpenRouter new client failed: {e}")
        pass
    
    # Try legacy OpenRouter as backup
    try:
        text = _call_openrouter_old(prompt, system)
        if text:
            print("[llm_chain] using OpenRouter API (legacy)")
            return text
    except Exception as e:
        print(f"[llm_chain] OpenRouter legacy failed: {e}")
        pass
    
    # Try Ollama (third priority)
    try:
        text = _call_ollama(prompt, model=None)
        if text:
            print("[llm_chain] using Ollama local model")
            return text
    except Exception as e:
        print(f"[llm_chain] Ollama failed: {e}")
        pass
    
    # Local fallback (always works)
    print("[llm_chain] using local fallback LLM")
    return _local_fallback(prompt, system)